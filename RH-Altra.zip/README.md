# RH-Altra

## Admin
- Accès: Menu **Admin · Utilisateurs** (visible uniquement pour ROLE_ADMIN)
- CRUD: `/api/admin/users`
