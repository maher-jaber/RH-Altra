export const environment = {
  production: true,

  // PROD: utiliser des URLs RELATIVES (même host/port via reverse-proxy)
  apiBaseUrl: '',
  mercureUrl: '/.well-known/mercure'
};
