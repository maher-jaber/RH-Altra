export const environment = {
  production: false,
  apiBaseUrl: 'http://localhost:8000',
  mercureUrl: 'http://localhost:3000/.well-known/mercure'
};
