import { Routes } from '@angular/router';

import { authGuard } from './core/guards/auth.guard';
import { adminGuard } from './core/guards/admin.guard';

import { LoginPageComponent } from './features/auth/login.page';
import { ForgotPasswordPageComponent } from './features/auth/forgot-password.page';
import { ResetPasswordPageComponent } from './features/auth/reset-password.page';

import { ShellComponent } from './features/dashboard/shell.component';
import { DashboardPageComponent } from './features/dashboard/dashboard.page';

// Congés (ancienne démo)
import { LeaveNewPageComponent } from './features/leave/leave-new.page';
import { LeaveMyPageComponent } from './features/leave/leave-my.page';

// Congés (nouveau module)
import { LeaveDashboardPage } from './features/leaves/leave-dashboard.page';
import { LeaveCalendarPage } from './features/leaves/leave-calendar.page';
import { LeavePendingManagerPage } from './features/leaves/leave-pending-manager.page';
import { LeaveCreatePage } from './features/leaves/leave-create.page';
import { LeaveDetailPage } from './features/leaves/leave-detail.page';

import { NotificationsPage } from './features/notifications/notifications.page';
import { SettingsPage } from './features/settings/settings.page';

import { AdminUsersPageComponent } from './features/admin/admin-users.page';
import { AdminDepartmentsPage } from './features/admin/admin-departments.page';

import { AdvancesPageComponent } from './features/advances/advances.page';
import { AdvanceDetailPage } from './features/advances/advance-detail.page';
import { ExitPermissionsPageComponent } from './features/exit-permissions/exit-permissions.page';
import { ExitPermissionDetailPage } from './features/exit-permissions/exit-permission-detail.page';
import { DailyReportsPageComponent } from './features/daily-reports/daily-reports.page';
import { ProfilePage } from './features/profile/profile.page';
import { PeopleHubPage } from './features/hr/people-hub.page';

export const APP_ROUTES: Routes = [
  { path: 'login', component: LoginPageComponent, title: 'Connexion' },
  { path: 'forgot-password', component: ForgotPasswordPageComponent, title: 'Mot de passe oublié' },
  { path: 'reset-password', component: ResetPasswordPageComponent, title: 'Réinitialisation' },

  {
    path: '',
    component: ShellComponent,
    canActivate: [authGuard],
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },

      { path: 'dashboard', component: DashboardPageComponent, title: 'Tableau de bord' },

      // Congés (module principal)
      { path: 'leaves', component: LeaveDashboardPage, title: 'Congés' },
      { path: 'leaves/create', component: LeaveCreatePage, title: 'Nouvelle demande de congé' },
      { path: 'leaves/detail/:id', component: LeaveDetailPage, title: 'Détail congé' },
      { path: 'leaves/my', component: LeaveMyPageComponent, title: 'Mes demandes de congé' },
      { path: 'leaves/pending-manager', component: LeavePendingManagerPage, title: 'Validation congés · Manager' },
      // RH removed: validation is manager1 / manager2 only.
      { path: 'leaves/calendar', component: LeaveCalendarPage, title: 'Calendrier congés' },
      // Team calendar is an admin tool (also linked from Settings)

      // Congés (ancienne démo conservée)
      { path: 'leave/new', component: LeaveNewPageComponent, title: 'Nouvelle demande de congé' },
      { path: 'leave/my', component: LeaveMyPageComponent, title: 'Mes demandes de congé' },

      { path: 'advances', component: AdvancesPageComponent, title: 'Avances / Acompte' },
      { path: 'advances/detail/:id', component: AdvanceDetailPage, title: 'Détail avance' },
      { path: 'exit-permissions', component: ExitPermissionsPageComponent, title: 'Autorisations de sortie' },
      { path: 'exit-permissions/detail/:id', component: ExitPermissionDetailPage, title: 'Détail autorisation' },
      { path: 'daily-reports', component: DailyReportsPageComponent, title: 'Compte-rendu journalier' },

      { path: 'notifications', component: NotificationsPage, title: 'Notifications' },
      { path: 'settings', component: SettingsPage, canActivate: [adminGuard], title: 'Paramètres' },

      { path: 'profile', component: ProfilePage, title: 'Mon profil' },

      // People hub (Admin / RH)
      { path: 'admin/people-hub', component: PeopleHubPage, canActivate: [adminGuard], title: 'Administration · Vue 360° employés' },

      { path: 'admin/users', component: AdminUsersPageComponent, canActivate: [adminGuard], title: 'Administration · Utilisateurs' },
      { path: 'admin/departments', component: AdminDepartmentsPage, canActivate: [adminGuard], title: 'Administration · Départements' },
    ],
  },

  { path: '**', redirectTo: '' },
];
