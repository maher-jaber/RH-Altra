import {
  MatDivider,
  MatDividerModule
} from "./chunk-L42ZYJRE.js";
import "./chunk-3LLODMIH.js";
import "./chunk-RU5QBMYY.js";
import "./chunk-2DXLVW4Q.js";
import "./chunk-4RMHXXWK.js";
import "./chunk-LFVCTHGI.js";
import "./chunk-AJN3JCM6.js";
import "./chunk-WDMUDEB6.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
