import {
  MatDivider,
  MatDividerModule
} from "./chunk-PDDBBIKT.js";
import "./chunk-H6NERJG2.js";
import "./chunk-FFY7VSBW.js";
import "./chunk-PCGAWVWW.js";
import "./chunk-E5ECCKE6.js";
import "./chunk-WDMUDEB6.js";
export {
  MatDivider,
  MatDividerModule
};
//# sourceMappingURL=@angular_material_divider.js.map
